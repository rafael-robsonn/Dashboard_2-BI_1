import unicodedata

import numpy as np
import pandas as pd

SEED = 20260917

LOJAS = [
    (1, "Asa Sul 108", "Plano Piloto", "Asa Sul", 1.45, "2016-03-01"),
    (2, "Asa Norte 205", "Plano Piloto", "Asa Norte", 1.30, "2016-08-15"),
    (3, "Sudoeste CLSW 103", "Plano Piloto", "Sudoeste", 1.20, "2018-02-01"),
    (4, "Lago Sul QI 11", "Plano Piloto", "Lago Sul", 1.10, "2019-05-10"),
    (5, "Águas Claras Araucárias", "Oeste", "Águas Claras", 1.35, "2017-11-20"),
    (6, "Águas Claras Rua 12", "Oeste", "Águas Claras", 0.95, "2025-03-03"),
    (7, "Taguatinga Centro", "Oeste", "Taguatinga", 1.25, "2015-06-01"),
    (8, "Taguatinga Sul CSA 2", "Oeste", "Taguatinga", 0.90, "2019-09-01"),
    (9, "Ceilândia Centro", "Oeste", "Ceilândia", 1.15, "2017-01-15"),
    (10, "Ceilândia P Sul", "Oeste", "Ceilândia", 0.85, "2020-04-20"),
    (11, "Samambaia Sul", "Oeste", "Samambaia", 0.80, "2020-10-05"),
    (12, "Vicente Pires Rua 4", "Oeste", "Vicente Pires", 0.75, "2021-07-12"),
    (13, "Guará II QE 38", "Sul", "Guará", 1.00, "2018-06-18"),
    (14, "Gama Setor Leste", "Sul", "Gama", 0.80, "2019-02-25"),
    (15, "Riacho Fundo I", "Sul", "Riacho Fundo", 0.65, "2022-03-14"),
    (16, "Sobradinho Quadra 8", "Norte", "Sobradinho", 0.85, "2018-10-01"),
    (17, "Planaltina Tradicional", "Norte", "Planaltina", 0.70, "2019-12-02"),
    (18, "Park Way Quadra 26", "Sul", "Park Way", 0.60, "2023-05-22"),
    (99, "CD SIA (digital)", "Centro de distribuição", "SIA", 0.0, "2020-01-10"),
]

CATEGORIAS = {
    "Medicamentos genéricos": dict(peso=0.20, preco=(8, 45), margem=(0.38, 0.52), itens=90),
    "Medicamentos de referência": dict(peso=0.17, preco=(18, 120), margem=(0.14, 0.24), itens=70),
    "MIP e antigripais": dict(peso=0.14, preco=(9, 55), margem=(0.28, 0.40), itens=45),
    "Dermocosméticos": dict(peso=0.11, preco=(30, 150), margem=(0.36, 0.50), itens=50),
    "Higiene pessoal": dict(peso=0.12, preco=(6, 40), margem=(0.24, 0.34), itens=45),
    "Infantil": dict(peso=0.06, preco=(10, 80), margem=(0.20, 0.30), itens=30),
    "Suplementos e vitaminas": dict(peso=0.07, preco=(20, 110), margem=(0.32, 0.46), itens=30),
    "Perfumaria": dict(peso=0.06, preco=(25, 170), margem=(0.30, 0.42), itens=25),
    "Conveniência": dict(peso=0.04, preco=(3, 18), margem=(0.30, 0.40), itens=20),
    "Ortopedia e aparelhos": dict(peso=0.03, preco=(25, 220), margem=(0.26, 0.36), itens=15),
}

MARCAS = ["Vitalis", "Neoquímica Lab", "Cerrado Pharma", "DermaPura", "Lumière", "BioNutri",
          "Pequeno Ser", "Medley Plus", "Achè Life", "EMS Care", "Sanaflora", "OrtoFlex"]

NOMES = ["Ana", "Bruno", "Carla", "Diego", "Eduarda", "Felipe", "Gabriela", "Henrique", "Isabela", "João",
         "Larissa", "Marcos", "Natália", "Otávio", "Paula", "Rafael", "Sabrina", "Thiago", "Vanessa", "Wesley"]
SOBRENOMES = ["Silva", "Souza", "Oliveira", "Pereira", "Lima", "Carvalho", "Ribeiro", "Almeida", "Rocha",
              "Martins", "Araújo", "Barbosa", "Gomes", "Nunes", "Mendes", "Cardoso"]


def sem_acento(s):
    return unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode()


def lojas():
    df = pd.DataFrame(LOJAS, columns=["loja_id", "nome", "regiao", "ra", "porte", "inauguracao"])
    df["inauguracao"] = pd.to_datetime(df["inauguracao"])
    return df


def produtos():
    rng = np.random.default_rng(SEED)
    linhas = []
    sku = 100000
    for cat, cfg in CATEGORIAS.items():
        prefixo = cat.split()[0]
        for i in range(cfg["itens"]):
            sku += 7
            preco = round(float(np.exp(rng.uniform(np.log(cfg["preco"][0]), np.log(cfg["preco"][1])))), 2)
            margem = float(rng.uniform(*cfg["margem"]))
            marca = str(rng.choice(MARCAS))
            linhas.append(dict(
                sku=sku, nome=f"{prefixo} {marca} {i + 1:03d}", categoria=cat, marca=marca,
                preco_base=preco, custo_base=round(preco * (1 - margem), 2),
                controlado=bool(cat.startswith("Medicamentos") and rng.random() < 0.18),
                popularidade=float(rng.pareto(1.6) + 0.2)))
    df = pd.DataFrame(linhas)
    df["popularidade"] = df["popularidade"] / df.groupby("categoria")["popularidade"].transform("sum")
    return df


def _cpfs(rng, n):
    base = rng.integers(0, 10, size=(n, 9))
    while True:
        _, idx, cnt = np.unique(base, axis=0, return_index=True, return_counts=True)
        repetidos = np.setdiff1d(np.arange(n), idx)
        if len(repetidos) == 0:
            break
        base[repetidos] = rng.integers(0, 10, size=(len(repetidos), 9))
    d1 = (base @ np.arange(10, 1, -1)) % 11
    d1 = np.where(d1 < 2, 0, 11 - d1)
    b2 = np.column_stack([base, d1])
    d2 = (b2 @ np.arange(11, 1, -1)) % 11
    d2 = np.where(d2 < 2, 0, 11 - d2)
    s = ["".join(map(str, r)) for r in np.column_stack([b2, d2])]
    return [f"{x[:3]}.{x[3:6]}.{x[6:9]}-{x[9:]}" for x in s]


def clientes(n=28000):
    rng = np.random.default_rng(SEED + 1)
    fis = lojas().query("loja_id != 99")
    ra = rng.choice(fis["ra"].values, size=n, p=(fis["porte"] / fis["porte"].sum()).values)
    nomes = [f"{rng.choice(NOMES)} {rng.choice(SOBRENOMES)} {rng.choice(SOBRENOMES)}" for _ in range(n)]
    cadastro = pd.Timestamp("2018-01-01") + pd.to_timedelta(rng.integers(0, 2900, n), unit="D")
    df = pd.DataFrame(dict(
        cliente_id=np.arange(1, n + 1), nome=nomes, cpf=_cpfs(rng, n),
        email=[f"{sem_acento(x.split()[0]).lower()}.{sem_acento(x.split()[-1]).lower()}{i}@exemplo.com.br" for i, x in enumerate(nomes)],
        telefone=[f"(61) 9{rng.integers(8000, 9999)}-{rng.integers(1000, 9999)}" for _ in range(n)],
        sexo=rng.choice(["F", "M"], n, p=[0.58, 0.42]),
        ano_nascimento=rng.normal(1982, 15, n).clip(1935, 2007).astype(int),
        ra=ra, data_cadastro=cadastro,
        tier_fidelidade=rng.choice(["Bronze", "Prata", "Ouro", "Diamante"], n, p=[0.55, 0.28, 0.13, 0.04]),
        consentimento_marketing=rng.random(n) < 0.63,
        afinidade=rng.gamma(1.4, 1.0, n),
    ))
    return df
