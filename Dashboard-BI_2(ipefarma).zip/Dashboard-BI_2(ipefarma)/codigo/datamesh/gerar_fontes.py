import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

RAIZ = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(RAIZ))
from comum import mundo  # noqa: E402

DOM = Path(__file__).parent / "dominios"
INICIO, FIM = pd.Timestamp("2025-01-01"), pd.Timestamp("2026-06-30")

RUPTURA_BASE = {17: 0.085, 14: 0.068, 16: 0.048, 15: 0.035, 11: 0.032}
NPS_BASE_LOJA = {1: 8.9, 4: 9.0, 3: 8.8, 5: 8.7, 17: 8.1, 14: 8.2, 9: 8.3, 10: 8.3}
RAS_DISTANTES = {"Planaltina", "Gama", "Sobradinho", "Park Way", "Riacho Fundo", "Samambaia"}

CAMPANHAS = [
    ("CMP-001", "Volta às aulas vitaminas", "Google Ads", "2025-01-10", "2025-02-28", 900, 3.6),
    ("CMP-002", "Carnaval protetor solar", "Meta Ads", "2025-02-15", "2025-03-10", 1100, 2.4),
    ("CMP-003", "Fidelidade Ouro push", "Push App", "2025-03-01", "2025-12-31", 120, 11.5),
    ("CMP-004", "Dermo outono", "Meta Ads", "2025-04-01", "2025-05-15", 850, 2.9),
    ("CMP-005", "Antigripais inverno", "Google Ads", "2025-05-15", "2025-08-15", 1300, 4.1),
    ("CMP-006", "Dia das Mães perfumaria", "Meta Ads", "2025-04-25", "2025-05-11", 1800, 3.2),
    ("CMP-007", "Newsletter mensal", "E-mail", "2025-01-01", "2026-06-30", 60, 9.0),
    ("CMP-008", "Seca Brasília hidratação", "TikTok Ads", "2025-07-01", "2025-09-20", 1400, 0.9),
    ("CMP-009", "Setembro Amarelo bem-estar", "Meta Ads", "2025-09-01", "2025-09-30", 700, 1.8),
    ("CMP-010", "Outubro Rosa", "Google Ads", "2025-10-01", "2025-10-31", 800, 2.7),
    ("CMP-011", "Black Friday dermo", "Meta Ads", "2025-11-17", "2025-11-30", 4200, 4.4),
    ("CMP-012", "Black Friday geral", "Google Ads", "2025-11-17", "2025-11-30", 3800, 3.9),
    ("CMP-013", "Black Friday TikTok", "TikTok Ads", "2025-11-17", "2025-11-30", 2600, 1.2),
    ("CMP-014", "Natal presentes", "Meta Ads", "2025-12-05", "2025-12-24", 2200, 3.0),
    ("CMP-015", "Fidelidade 2026 push", "Push App", "2026-01-01", "2026-06-30", 150, 12.8),
    ("CMP-016", "Verão proteção solar", "TikTok Ads", "2026-01-05", "2026-02-28", 1600, 1.1),
    ("CMP-017", "Genéricos economia", "Google Ads", "2026-02-01", "2026-04-30", 950, 5.2),
    ("CMP-018", "Dia das Mães 2026", "Meta Ads", "2026-04-24", "2026-05-10", 2000, 3.4),
    ("CMP-019", "Inverno 2026 imunidade", "Google Ads", "2026-05-10", "2026-06-30", 1250, 4.3),
    ("CMP-020", "Reativação clientes inativos", "E-mail", "2026-03-01", "2026-06-30", 90, 6.5),
]


def norm(v):
    v = np.asarray(v, dtype=float)
    return v / v.sum()


def main():
    rng = np.random.default_rng(mundo.SEED + 20)
    for d in ["vendas", "logistica", "clientes", "marketing"]:
        (DOM / d / "fontes").mkdir(parents=True, exist_ok=True)

    lojas = mundo.lojas()
    fis = lojas.query("loja_id != 99").reset_index(drop=True)
    produtos = mundo.produtos()
    clientes = mundo.clientes()
    datas = pd.date_range(INICIO, FIM)
    nd, nl = len(datas), len(fis)
    anos = (datas - INICIO).days.values / 365.25

    monitorados = produtos.sort_values("popularidade", ascending=False).groupby("categoria").head(6).reset_index(drop=True)
    ns = len(monitorados)
    antigripal = (monitorados["categoria"] == "MIP e antigripais").values

    base_loja = np.array([RUPTURA_BASE.get(l, rng.uniform(0.012, 0.026)) for l in fis.loja_id])
    taxa = np.repeat(base_loja[None, :], nd, axis=0)
    crise_gripe = ((datas >= "2025-06-10") & (datas <= "2025-07-31"))
    greve_norte = ((datas >= "2026-03-02") & (datas <= "2026-03-27"))
    norte = (fis["regiao"] == "Norte").values
    taxa = taxa + greve_norte[:, None] * norte[None, :] * 0.09
    taxa = np.clip(taxa * rng.lognormal(0, 0.25, taxa.shape), 0, 0.6)
    ativa = (datas.values[:, None] >= fis["inauguracao"].values[None, :])

    rup = rng.random((nd, nl, ns)) < taxa[:, :, None]
    rup[crise_gripe] |= (rng.random((crise_gripe.sum(), nl, ns)) < 0.35) & antigripal[None, None, :]
    rup &= ativa[:, :, None]

    demanda_media = 6 * fis["porte"].values[None, :, None] * monitorados["popularidade"].values[None, None, :] * 10
    estoque = np.where(rup, 0, rng.poisson(np.maximum(demanda_media * rng.uniform(4, 12, (nd, nl, ns)), 1)))
    dd, ll, ss = np.nonzero(ativa[:, :, None] & np.ones((1, 1, ns), dtype=bool))
    wms = pd.DataFrame({
        "COD_FILIAL": [f"F{x:03d}" for x in fis["loja_id"].values[ll]],
        "DT_POSICAO": datas.strftime("%Y%m%d").values[dd],
        "COD_ITEM": monitorados["sku"].values[ss],
        "QTD_DISPONIVEL": estoque[dd, ll, ss],
        "QTD_MINIMA": np.ceil(demanda_media[0, ll, ss] * 2).astype(int),
        "VLR_CUSTO_MEDIO": np.round(monitorados["custo_base"].values[ss] * 1.03, 2),
    })
    wms["VLR_CUSTO_MEDIO"] = wms["VLR_CUSTO_MEDIO"].map(lambda v: f"{v:.2f}".replace(".", ","))
    wms.to_csv(DOM / "logistica" / "fontes" / "wms_posicao_estoque.csv", sep=";", index=False)

    taxa_rup_dia = rup.mean(axis=2)
    sazonal = np.array([0.93, 0.91, 0.98, 1.0, 1.05, 1.10, 1.12, 1.08, 1.02, 1.0, 1.07, 1.16])[datas.month - 1]
    semana = np.array([1.02, 0.97, 0.98, 1.0, 1.08, 1.18, 0.77])[datas.weekday]
    lam = 13 * fis["porte"].values[None, :] * (sazonal * semana * (1 + 0.05 * anos))[:, None] * (1 - 0.9 * taxa_rup_dia) * ativa
    cont = rng.poisson(lam)
    di, li = np.nonzero(cont)
    r = cont[di, li]
    di, li = np.repeat(di, r), np.repeat(li, r)
    n_loja = len(di)

    lam_dig = 34 * sazonal * semana * (1 + 0.45 * anos)
    cont_d = rng.poisson(lam_dig)
    dig_di = np.repeat(np.arange(nd), cont_d)
    n_dig = len(dig_di)

    camp = pd.DataFrame(CAMPANHAS, columns=["campaign_id", "campaign_name", "network", "start", "end", "daily_budget", "roas_alvo"])
    ads_linhas, camp_ped = [], []
    for c in camp.itertuples():
        dias = pd.date_range(c.start, c.end)
        spend = np.round(c.daily_budget * rng.uniform(0.75, 1.15, len(dias)), 2)
        cpm = {"Google Ads": 22, "Meta Ads": 14, "TikTok Ads": 9, "E-mail": 9.0, "Push App": 5.0}[c.network]
        impr = (spend / cpm * 1000).astype(int)
        ctr = {"Google Ads": 0.032, "Meta Ads": 0.012, "TikTok Ads": 0.007, "E-mail": 0.018, "Push App": 0.031}[c.network]
        cliques = rng.binomial(impr, ctr)
        for d, s, im, cl in zip(dias, spend, impr, cliques):
            ads_linhas.append(dict(date=d.strftime("%Y-%m-%d"), campaign_id=c.campaign_id, network=c.network,
                                   spend=s, impressions=int(im), clicks=int(cl)))
            pedidos_c = rng.poisson(s * c.roas_alvo * rng.uniform(0.8, 1.2) / 150)
            if pedidos_c:
                camp_ped.append((d, c.campaign_id, pedidos_c))
    ads = pd.DataFrame(ads_linhas)
    ads_por_rede = {rede: g.drop(columns="network") for rede, g in ads.groupby("network")}
    for rede, g in ads_por_rede.items():
        g.to_csv(DOM / "marketing" / "fontes" / f"ads_{rede.lower().replace(' ', '_')}.csv", index=False)
    camp.drop(columns=["roas_alvo"]).to_csv(DOM / "marketing" / "fontes" / "cadastro_campanhas.csv", index=False)

    camp_dias = np.array([datas.get_loc(pd.Timestamp(d)) for d, _, k in camp_ped for _ in range(k)], dtype=int)
    camp_ids = np.array([cid for _, cid, k in camp_ped for _ in range(k)])
    n_camp = len(camp_dias)

    total = n_loja + n_dig + n_camp
    dia_all = np.concatenate([di, dig_di, camp_dias])
    loja_all = np.concatenate([fis["loja_id"].values[li], np.full(n_dig + n_camp, 99)])
    anos_all = anos[dia_all]
    canal = np.where(loja_all == 99, np.where(rng.random(total) < np.clip(0.52 + 0.2 * anos_all, 0, 0.85), "App", "Site"), "Loja física")
    utm = np.concatenate([np.full(n_loja + n_dig, None), camp_ids])

    hora = np.where(loja_all == 99, rng.choice(np.arange(6, 24), total, p=norm([2, 3, 5, 6, 6, 7, 7, 6, 6, 6, 7, 7, 8, 9, 9, 8, 5, 3])),
                    rng.choice(np.arange(7, 23), total, p=norm([2, 4, 6, 7, 8, 9, 8, 6, 6, 7, 8, 9, 8, 6, 4, 2])))
    ts = datas.values[dia_all] + (hora * 3600 + rng.integers(0, 3600, total)).astype("timedelta64[s]")

    aff = norm(clientes["afinidade"].values)
    cli_idx = rng.choice(len(clientes), total, p=aff)
    ident = (loja_all == 99) | (rng.random(total) < 0.66)
    valor_bruto = np.round(rng.lognormal(np.log(np.where(loja_all == 99, 150, 105)), 0.62, total) * (1.045 ** anos_all), 2)
    desconto = np.round(valor_bruto * np.where(utm != None, rng.choice([0.05, 0.10, 0.15], total), rng.choice([0, 0, 0.03, 0.05], total)), 2)  # noqa: E711

    ordem = np.argsort(ts)
    eventos = pd.DataFrame({
        "evento": "venda_finalizada",
        "id_venda": [f"V{i:08d}" for i in range(1, total + 1)],
        "ts": pd.to_datetime(ts[ordem]).strftime("%Y-%m-%dT%H:%M:%S-03:00"),
        "filial": loja_all[ordem],
        "origem": canal[ordem],
        "cpf_cliente": np.where(ident[ordem], clientes["cpf"].values[cli_idx[ordem]], None),
        "total_bruto": valor_bruto[ordem],
        "total_desconto": desconto[ordem],
        "qtd_itens": np.where(loja_all[ordem] == 99, 1 + rng.poisson(1.8, total), 1 + rng.poisson(0.9, total)),
        "utm_campaign": utm[ordem],
    })
    eventos["mes"] = eventos["ts"].str[:7]
    for mes, g in eventos.groupby("mes"):
        with open(DOM / "vendas" / "fontes" / f"pdv_eventos_{mes.replace('-', '')}.jsonl", "w", encoding="utf-8") as f:
            for rec in g.drop(columns="mes").to_dict("records"):
                rec = {k: (None if isinstance(v, float) and np.isnan(v) else v) for k, v in rec.items()}
                f.write(json.dumps(rec, ensure_ascii=False, default=lambda o: o.item() if hasattr(o, "item") else str(o)) + "\n")

    dig = eventos[eventos["filial"] == 99].reset_index(drop=True)
    nd_ = len(dig)
    cli_map = clientes.set_index("cpf")
    ra_dest = cli_map.loc[dig["cpf_cliente"], "ra"].values
    ts_v = pd.to_datetime(dig["ts"].str[:19])
    express = rng.random(nd_) < 0.36
    prometido = ts_v + pd.to_timedelta(np.where(express, 4, 24), unit="h")
    chuva = ts_v.dt.month.isin([11, 12, 1, 2, 3]).values
    distante = np.isin(ra_dest, list(RAS_DISTANTES))
    migracao_tms = ((ts_v >= "2025-10-06") & (ts_v <= "2025-11-16")).values
    p_atraso = 0.07 * np.where(chuva, 1.7, 1) * np.where(distante, 1.6, 1) * np.where(migracao_tms, 2.6, 1) * np.where(express, 1.3, 1)
    atrasou = rng.random(nd_) < np.clip(p_atraso, 0, 0.9)
    minutos = np.where(atrasou, rng.exponential(np.where(express, 55, 180)) + 10, -rng.exponential(np.where(express, 40, 300)))
    entregue = prometido + pd.to_timedelta(minutos, unit="m")
    extraviado = rng.random(nd_) < 0.004
    tms = [dict(
        shipment={"id": f"ENV-{i + 1:07d}", "order_ref": dig.at[i, "id_venda"], "service": "EXPRESS_4H" if express[i] else "STANDARD_24H"},
        destination={"district": ra_dest[i]},
        promised_at=prometido.iloc[i].isoformat(),
        delivered_at=None if extraviado[i] else entregue.iloc[i].isoformat(),
        status="LOST" if extraviado[i] else "DELIVERED",
    ) for i in range(nd_)]
    with open(DOM / "logistica" / "fontes" / "tms_entregas.json", "w", encoding="utf-8") as f:
        json.dump({"source": "tms-api/v2", "exported_at": "2026-07-01T03:00:00-03:00", "items": tms}, f, ensure_ascii=False)

    eventos_id = eventos[eventos["cpf_cliente"].notna()].reset_index(drop=True)
    resp = rng.random(len(eventos_id)) < 0.075
    amostra = eventos_id[resp].reset_index(drop=True)
    na = len(amostra)
    ts_a = pd.to_datetime(amostra["ts"].str[:19])
    dia_idx = (ts_a.dt.normalize() - INICIO).dt.days.values
    fil = amostra["filial"].values
    base = np.array([NPS_BASE_LOJA.get(f, 8.5) for f in fil])
    atraso_map = pd.Series(minutos, index=dig["id_venda"])
    extr_map = pd.Series(extraviado, index=dig["id_venda"])
    atr = amostra["id_venda"].map(atraso_map).fillna(-1).values
    ext = amostra["id_venda"].map(extr_map).fillna(False).astype(bool).values
    col_loja = {lid: i for i, lid in enumerate(fis["loja_id"])}
    rup_cliente = np.array([taxa_rup_dia[d, col_loja[f]] if f in col_loja else 0.0 for d, f in zip(dia_idx, fil)])
    afetado = rng.random(na) < np.clip(rup_cliente * 5, 0, 0.9)
    nota = base + rng.normal(0, 1.25, na) - np.where(atr > 120, 3.4, np.where(atr > 30, 1.6, np.where(atr > 0, 0.6, 0))) - afetado * 2.6 - ext * 5
    nota = np.clip(np.round(nota), 0, 10).astype(int)
    motivo = np.select(
        [ext, atr > 30, afetado, nota >= 9, nota <= 6],
        ["Pedido não chegou", "Entrega atrasada", "Produto em falta", "Atendimento e preço", "Preço"], "Sem comentário")
    pesquisa = pd.DataFrame({
        "Response ID": [f"R-{rng.integers(1e9, 9e9)}-{i}" for i in range(na)],
        "Submitted At": (ts_a + pd.to_timedelta(rng.integers(2, 72, na), unit="h")).dt.strftime("%d/%m/%Y %H:%M"),
        "Email": cli_map.loc[amostra["cpf_cliente"], "email"].values,
        "CPF": amostra["cpf_cliente"].values,
        "Transaction": amostra["id_venda"].values,
        "Store": [f"Loja {f}" if f != 99 else "Online" for f in fil],
        "Q1 - De 0 a 10, quanto recomendaria?": nota,
        "Q2 - Motivo principal": motivo,
    })
    pesquisa.to_csv(DOM / "clientes" / "fontes" / "survey_nps_export.csv", index=False)
    clientes.drop(columns=["afinidade"]).assign(data_cadastro=lambda d: d.data_cadastro.dt.strftime("%Y-%m-%d")).to_csv(
        DOM / "clientes" / "fontes" / "crm_cadastro_clientes.csv", sep=";", index=False)
    monitorados[["sku", "categoria", "nome"]].to_csv(DOM / "logistica" / "fontes" / "wms_itens_monitorados.csv", sep=";", index=False)
    lojas.drop(columns=["porte"]).to_csv(DOM / "logistica" / "fontes" / "cadastro_filiais.csv", sep=";", index=False)

    print(f"vendas: {total:,} eventos ({n_camp:,} atribuídos a campanhas)")
    print(f"logistica: {len(wms):,} posições de estoque | {nd_:,} entregas")
    print(f"clientes: {na:,} respostas NPS | {len(clientes):,} cadastros")
    print(f"marketing: {len(ads):,} linhas de mídia em {len(ads_por_rede)} redes")


if __name__ == "__main__":
    main()
