import json
import sys
from pathlib import Path

import duckdb
import pandas as pd

RAIZ = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(RAIZ))
from comum import mundo  # noqa: E402
from datamesh.plataforma import catalogo  # noqa: E402

CONSUMIDOR = "diretoria_bi"
SAIDA = RAIZ / "dashboards" / "dados_mesh.json"


def registros(df):
    df = df.copy()
    for c in df.columns:
        if pd.api.types.is_datetime64_any_dtype(df[c]):
            df[c] = df[c].dt.strftime("%Y-%m-%d")
        elif pd.api.types.is_float_dtype(df[c]):
            df[c] = df[c].round(4)
    return json.loads(df.to_json(orient="records", force_ascii=False))


def main():
    produtos = {pid: catalogo.ler(pid, CONSUMIDOR) for pid in [
        "vendas.pedidos", "vendas.vendas_diarias_loja", "logistica.ruptura_diaria_loja", "logistica.entregas",
        "clientes.respostas_nps", "clientes.perfil_cliente", "marketing.campanhas", "marketing.investimento_diario"]}

    negado = None
    try:
        catalogo.ler("clientes.perfil_cliente", "parceiro_externo_trade")
    except catalogo.AcessoNegado as e:
        negado = str(e)
    try:
        catalogo.ler("clientes.respostas_nps_rascunho", CONSUMIDOR)
    except catalogo.ProdutoIndisponivel:
        pass

    con = duckdb.connect()
    for pid, df in produtos.items():
        con.register(pid.replace(".", "__"), df)
    lojas = mundo.lojas()[["loja_id", "nome", "regiao", "ra"]]
    con.register("lojas", lojas)

    mensal_loja = con.execute("""
        WITH v AS (
            SELECT strftime(data, '%Y-%m') AS mes, loja_id, sum(pedidos) AS pedidos, sum(receita_liquida_brl) AS receita
            FROM vendas__vendas_diarias_loja GROUP BY ALL
        ), r AS (
            SELECT strftime(data, '%Y-%m') AS mes, loja_id, avg(taxa_ruptura) AS ruptura, avg(ruptura_antigripais) AS ruptura_gripe
            FROM logistica__ruptura_diaria_loja GROUP BY ALL
        ), n AS (
            SELECT strftime(p.data, '%Y-%m') AS mes, n.loja_id,
                   count(*) AS respostas,
                   count(*) FILTER (WHERE classe_nps = 'promotor') AS promotores,
                   count(*) FILTER (WHERE classe_nps = 'detrator') AS detratores
            FROM clientes__respostas_nps n JOIN vendas__pedidos p USING (pedido_id)
            GROUP BY ALL
        ), e AS (
            SELECT strftime(p.data, '%Y-%m') AS mes, 99 AS loja_id, count(*) AS envios,
                   count(*) FILTER (WHERE no_prazo) AS no_prazo, count(*) FILTER (WHERE status = 'extraviado') AS extraviados
            FROM logistica__entregas e JOIN vendas__pedidos p USING (pedido_id)
            GROUP BY ALL
        )
        SELECT v.mes, v.loja_id, v.pedidos, round(v.receita, 2) AS receita,
               r.ruptura, r.ruptura_gripe,
               coalesce(n.respostas, 0) AS respostas, coalesce(n.promotores, 0) AS promotores, coalesce(n.detratores, 0) AS detratores,
               coalesce(e.envios, 0) AS envios, coalesce(e.no_prazo, 0) AS no_prazo, coalesce(e.extraviados, 0) AS extraviados
        FROM v
        LEFT JOIN r USING (mes, loja_id)
        LEFT JOIN n USING (mes, loja_id)
        LEFT JOIN e USING (mes, loja_id)
        ORDER BY 1, 2
    """).df()

    atraso_nps = con.execute("""
        SELECT strftime(p.data, '%Y-%m') AS mes,
               CASE WHEN e.status = 'extraviado' THEN 'Extraviado'
                    WHEN e.atraso_min <= 0 THEN 'No prazo'
                    WHEN e.atraso_min <= 30 THEN 'Até 30 min'
                    WHEN e.atraso_min <= 120 THEN '30 a 120 min'
                    ELSE 'Mais de 2 h' END AS faixa,
               count(*) AS respostas,
               count(*) FILTER (WHERE n.classe_nps = 'promotor') AS promotores,
               count(*) FILTER (WHERE n.classe_nps = 'detrator') AS detratores
        FROM clientes__respostas_nps n
        JOIN logistica__entregas e USING (pedido_id)
        JOIN vendas__pedidos p USING (pedido_id)
        GROUP BY ALL
    """).df()

    ruptura_nps = con.execute("""
        SELECT strftime(p.data, '%Y-%m') AS mes,
               CASE WHEN r.taxa_ruptura < 0.02 THEN 'Menos de 2%'
                    WHEN r.taxa_ruptura < 0.05 THEN '2% a 5%'
                    WHEN r.taxa_ruptura < 0.10 THEN '5% a 10%'
                    ELSE '10% ou mais' END AS faixa,
               count(*) AS respostas,
               count(*) FILTER (WHERE n.classe_nps = 'promotor') AS promotores,
               count(*) FILTER (WHERE n.classe_nps = 'detrator') AS detratores
        FROM clientes__respostas_nps n
        JOIN vendas__pedidos p USING (pedido_id)
        JOIN logistica__ruptura_diaria_loja r ON r.loja_id = p.loja_id AND r.data = p.data
        GROUP BY ALL
    """).df()

    entregas_ra = con.execute("""
        SELECT strftime(prometido_em, '%Y-%m') AS mes, ra_destino AS ra, count(*) AS envios,
               count(*) FILTER (WHERE no_prazo) AS no_prazo
        FROM logistica__entregas GROUP BY ALL
    """).df()

    campanhas = con.execute("""
        WITH inv AS (
            SELECT campanha_id, strftime(data, '%Y-%m') AS mes, sum(investimento_brl) AS investimento, sum(cliques) AS cliques
            FROM marketing__investimento_diario GROUP BY ALL
        ), ped AS (
            SELECT p.campanha_id, strftime(p.data, '%Y-%m') AS mes, count(*) AS pedidos, sum(p.valor_liquido_brl) AS receita,
                   count(*) FILTER (WHERE c.rede IN ('E-mail', 'Push App') AND NOT pc.consentimento_marketing) AS sem_consentimento
            FROM vendas__pedidos p
            JOIN marketing__campanhas c USING (campanha_id)
            LEFT JOIN clientes__perfil_cliente pc USING (cliente_pid)
            WHERE p.campanha_id IS NOT NULL
            GROUP BY ALL
        )
        SELECT inv.mes, c.campanha_id, c.nome, c.rede, round(inv.investimento, 2) AS investimento, inv.cliques,
               coalesce(ped.pedidos, 0) AS pedidos, round(coalesce(ped.receita, 0), 2) AS receita,
               coalesce(ped.sem_consentimento, 0) AS sem_consentimento
        FROM inv JOIN marketing__campanhas c USING (campanha_id)
        LEFT JOIN ped USING (campanha_id, mes)
        ORDER BY 1, 2
    """).df()
    con.close()

    prods, execucoes, acessos = catalogo.resumo()
    con_cat = duckdb.connect(str(catalogo.CATALOGO), read_only=True)
    falhas = con_cat.execute("""
        SELECT e.produto_id, e.versao, c.regra, c.detalhe
        FROM checagem c JOIN execucao e USING (execucao_id)
        WHERE NOT c.ok ORDER BY e.executado_em""").df()
    con_cat.close()
    dados = dict(
        lojas=registros(lojas),
        mensal_loja=registros(mensal_loja),
        atraso_nps=registros(atraso_nps),
        ruptura_nps=registros(ruptura_nps),
        entregas_ra=registros(entregas_ra),
        campanhas=registros(campanhas),
        catalogo=registros(prods),
        execucoes=registros(execucoes.assign(executado_em=execucoes["executado_em"].dt.strftime("%Y-%m-%d %H:%M"))),
        acessos=registros(acessos),
        falhas=registros(falhas),
        acesso_negado=negado,
        relogio=catalogo.RELOGIO.strftime("%Y-%m-%d %H:%M"),
    )
    SAIDA.parent.mkdir(exist_ok=True)
    SAIDA.write_text(json.dumps(dados, ensure_ascii=False), encoding="utf-8")
    print(f"dados cruzados gravados em {SAIDA.relative_to(RAIZ)} ({SAIDA.stat().st_size / 1024:.0f} KB)")


if __name__ == "__main__":
    main()
