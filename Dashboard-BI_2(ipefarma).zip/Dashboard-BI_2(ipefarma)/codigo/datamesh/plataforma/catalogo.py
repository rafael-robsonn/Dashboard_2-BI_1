import json
import os
import uuid
from datetime import datetime
from pathlib import Path

import duckdb
import pandas as pd

from .contrato import Contrato, validar
from .governanca import validar_politicas_globais

MESH = Path(__file__).resolve().parents[1]
CATALOGO = MESH / "plataforma" / "catalogo.duckdb"
RELOGIO = datetime.fromisoformat(os.environ.get("MESH_AGORA", "2026-07-01T06:00:00"))

DDL = """
CREATE TABLE IF NOT EXISTS produto (
    id VARCHAR PRIMARY KEY, dominio VARCHAR, nome VARCHAR, dono VARCHAR, descricao VARCHAR,
    classificacao VARCHAR, granularidade VARCHAR, versao VARCHAR, caminho VARCHAR, status VARCHAR,
    linhas BIGINT, atualizado_ate TIMESTAMP, frescor_max_horas INTEGER, publicado_em TIMESTAMP, esquema JSON
);
CREATE TABLE IF NOT EXISTS execucao (
    execucao_id VARCHAR, produto_id VARCHAR, versao VARCHAR, executado_em TIMESTAMP,
    status VARCHAR, linhas BIGINT, checagens INTEGER, falhas INTEGER
);
CREATE TABLE IF NOT EXISTS checagem (execucao_id VARCHAR, regra VARCHAR, ok BOOLEAN, detalhe VARCHAR);
CREATE TABLE IF NOT EXISTS linhagem (produto_id VARCHAR, origem VARCHAR);
CREATE TABLE IF NOT EXISTS autorizacao (produto_id VARCHAR, consumidor VARCHAR);
CREATE TABLE IF NOT EXISTS acesso (ts TIMESTAMP, consumidor VARCHAR, produto_id VARCHAR, permitido BOOLEAN, motivo VARCHAR);
"""


class ProdutoIndisponivel(Exception):
    pass


class AcessoNegado(Exception):
    pass


def _con(somente_leitura=False):
    if somente_leitura and CATALOGO.exists():
        return duckdb.connect(str(CATALOGO), read_only=True)
    con = duckdb.connect(str(CATALOGO))
    con.execute(DDL)
    return con


def publicar(caminho_contrato: Path, df: pd.DataFrame):
    contrato = Contrato.carregar(caminho_contrato)
    execucao_id = uuid.uuid4().hex[:12]
    checagens = validar(contrato, df)
    for v in validar_politicas_globais(contrato, df):
        checagens.append(type(checagens[0])(f"governança: {v}", False, ""))

    coluna_tempo = contrato.sla.get("coluna_tempo")
    atualizado_ate = pd.to_datetime(df[coluna_tempo]).max().to_pydatetime() if coluna_tempo and coluna_tempo in df else None
    if atualizado_ate is not None:
        idade_h = (RELOGIO - atualizado_ate).total_seconds() / 3600
        limite = contrato.sla["frescor_max_horas"]
        checagens.append(type(checagens[0])(f"frescor <= {limite}h", idade_h <= limite, f"{idade_h:.0f}h"))

    falhas = [c for c in checagens if not c.ok]
    status = "publicado" if not falhas else "rejeitado"

    con = _con()
    try:
        if status == "publicado":
            destino_dir = MESH / "dominios" / contrato.dominio / "produtos" / contrato.nome / contrato.versao_major
            destino_dir.mkdir(parents=True, exist_ok=True)
            destino = destino_dir / "dados.parquet"
            tmp = destino_dir / f".{execucao_id}.parquet"
            df.to_parquet(tmp, index=False)
            os.replace(tmp, destino)
            con.execute("DELETE FROM produto WHERE id = ?", [contrato.id])
            con.execute("INSERT INTO produto VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [
                contrato.id, contrato.dominio, contrato.nome, contrato.dono, contrato.descricao.strip(),
                contrato.classificacao, contrato.granularidade, contrato.versao,
                str(destino.relative_to(MESH)), status, len(df), atualizado_ate,
                contrato.sla["frescor_max_horas"], datetime.now(), json.dumps(contrato.esquema, ensure_ascii=False)])
            con.execute("DELETE FROM linhagem WHERE produto_id = ?", [contrato.id])
            con.execute("DELETE FROM autorizacao WHERE produto_id = ?", [contrato.id])
            for origem in contrato.origem:
                con.execute("INSERT INTO linhagem VALUES (?, ?)", [contrato.id, origem])
            for consumidor in contrato.consumidores_autorizados:
                con.execute("INSERT INTO autorizacao VALUES (?, ?)", [contrato.id, consumidor])
        con.execute("INSERT INTO execucao VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                    [execucao_id, contrato.id, contrato.versao, datetime.now(), status, len(df), len(checagens), len(falhas)])
        con.executemany("INSERT INTO checagem VALUES (?, ?, ?, ?)",
                        [[execucao_id, c.regra, c.ok, c.detalhe] for c in checagens])
    finally:
        con.close()

    marca = "OK " if status == "publicado" else "REJ"
    print(f"  [{marca}] {contrato.id} v{contrato.versao}: {len(df):,} linhas, {len(checagens)} checagens, {len(falhas)} falhas")
    for f in falhas:
        print(f"        falha: {f.regra} {f.detalhe}")
    return status


def ler(produto_id: str, consumidor: str) -> pd.DataFrame:
    con = _con()
    try:
        linha = con.execute("SELECT caminho, status, classificacao FROM produto WHERE id = ?", [produto_id]).fetchone()
        if linha is None or linha[1] != "publicado":
            con.execute("INSERT INTO acesso VALUES (?, ?, ?, false, 'indisponível')", [datetime.now(), consumidor, produto_id])
            raise ProdutoIndisponivel(produto_id)
        caminho, _, classificacao = linha
        if classificacao == "restrito":
            autorizado = con.execute("SELECT count(*) FROM autorizacao WHERE produto_id = ? AND consumidor = ?",
                                     [produto_id, consumidor]).fetchone()[0] > 0
            if not autorizado:
                con.execute("INSERT INTO acesso VALUES (?, ?, ?, false, 'não autorizado')", [datetime.now(), consumidor, produto_id])
                raise AcessoNegado(f"{consumidor} -> {produto_id}")
        con.execute("INSERT INTO acesso VALUES (?, ?, ?, true, 'ok')", [datetime.now(), consumidor, produto_id])
    finally:
        con.close()
    return pd.read_parquet(MESH / caminho)


def resumo():
    con = _con(somente_leitura=True)
    try:
        produtos = con.execute("""
            SELECT p.id, p.dominio, p.nome, p.dono, p.classificacao, p.versao, p.linhas, p.atualizado_ate,
                   p.frescor_max_horas, e.checagens, e.falhas,
                   (SELECT string_agg(origem, ' | ') FROM linhagem l WHERE l.produto_id = p.id) AS origens
            FROM produto p
            JOIN (SELECT produto_id, checagens, falhas, row_number() OVER (PARTITION BY produto_id ORDER BY executado_em DESC) rn
                  FROM execucao WHERE status = 'publicado') e ON e.produto_id = p.id AND e.rn = 1
            ORDER BY p.dominio, p.nome""").df()
        execucoes = con.execute("SELECT produto_id, status, checagens, falhas, executado_em FROM execucao ORDER BY executado_em").df()
        acessos = con.execute("SELECT consumidor, produto_id, permitido, motivo, count(*) n FROM acesso GROUP BY ALL ORDER BY 1, 2").df()
    finally:
        con.close()
    return produtos, execucoes, acessos
