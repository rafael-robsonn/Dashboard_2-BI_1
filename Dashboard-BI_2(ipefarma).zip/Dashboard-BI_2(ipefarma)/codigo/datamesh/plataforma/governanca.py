import hashlib
import hmac
import os
import re
import warnings

import pandas as pd

_CHAVE_DEV = b"chave-de-desenvolvimento-nao-usar-em-producao"

PADROES_PII = {
    "cpf": re.compile(r"(?<![\w.-])(?:\d{3}\.\d{3}\.\d{3}-\d{2}|\d{11})(?![\w-])"),
    "email": re.compile(r"[\w.+-]+@[\w-]+\.[\w.]+"),
    "telefone": re.compile(r"(?<![\w-])(?:\(\d{2}\)\s?9\d{4}-\d{4}|\+55\s?\d{2}\s?9\d{8})(?![\w-])"),
}

CLASSIFICACOES = {"publico_interno", "interno", "restrito"}
TIPOS_GLOBAIS = {"string", "int", "float", "decimal", "bool", "date", "timestamp"}
NOME_COLUNA = re.compile(r"^[a-z][a-z0-9_]*$")


def _chave():
    valor = os.environ.get("MESH_PSEUDO_KEY")
    if not valor:
        warnings.warn("MESH_PSEUDO_KEY ausente; usando chave de desenvolvimento", stacklevel=3)
        return _CHAVE_DEV
    if len(valor) < 32:
        raise ValueError("MESH_PSEUDO_KEY precisa de pelo menos 32 caracteres")
    return valor.encode()


def pseudonimizar_cpf(serie: pd.Series) -> pd.Series:
    chave = _chave()

    def _h(v):
        if v is None or (isinstance(v, float) and pd.isna(v)):
            return None
        digitos = re.sub(r"\D", "", str(v))
        if len(digitos) != 11:
            return None
        return "cli_" + hmac.new(chave, digitos.encode(), hashlib.sha256).hexdigest()[:24]

    return serie.map(_h)


def varrer_pii(df: pd.DataFrame, amostra=5000):
    achados = []
    textos = df.select_dtypes(include=["object", "string"])
    if textos.empty:
        return achados
    sub = textos.sample(min(len(textos), amostra), random_state=0) if len(textos) > amostra else textos
    for col in sub.columns:
        valores = sub[col].dropna().astype(str)
        for tipo, padrao in PADROES_PII.items():
            if valores.str.contains(padrao).any():
                achados.append((col, tipo))
    return achados


def validar_politicas_globais(contrato, df):
    violacoes = []
    if contrato.classificacao not in CLASSIFICACOES:
        violacoes.append(f"classificação inválida: {contrato.classificacao}")
    for campo in contrato.esquema:
        if not NOME_COLUNA.match(campo["nome"]):
            violacoes.append(f"coluna fora do padrão snake_case: {campo['nome']}")
        if campo["tipo"] not in TIPOS_GLOBAIS:
            violacoes.append(f"tipo não reconhecido pela plataforma: {campo['nome']}:{campo['tipo']}")
        if campo["nome"].startswith("valor") and not campo["nome"].endswith("_brl"):
            violacoes.append(f"valor monetário sem sufixo _brl: {campo['nome']}")
    for col, tipo in varrer_pii(df):
        violacoes.append(f"PII em claro detectada ({tipo}) na coluna {col}")
    if contrato.classificacao != "restrito" and any(c.get("pii") for c in contrato.esquema):
        violacoes.append("campo marcado como PII exige classificação restrito")
    if contrato.classificacao == "publico_interno" and any(c.get("pseudonimo") for c in contrato.esquema):
        violacoes.append("dado pseudonimizado segue sendo dado pessoal pela LGPD e não pode ser publico_interno")
    return violacoes
