from dataclasses import dataclass, field
from pathlib import Path

import duckdb
import pandas as pd
import yaml

TIPOS_PANDAS = {
    "string": lambda s: pd.api.types.is_string_dtype(s) or pd.api.types.is_object_dtype(s),
    "int": pd.api.types.is_integer_dtype,
    "float": pd.api.types.is_float_dtype,
    "decimal": lambda s: pd.api.types.is_float_dtype(s) or pd.api.types.is_integer_dtype(s),
    "bool": pd.api.types.is_bool_dtype,
    "date": lambda s: pd.api.types.is_datetime64_any_dtype(s) or s.dropna().map(type).astype(str).str.contains("date").all(),
    "timestamp": pd.api.types.is_datetime64_any_dtype,
}


@dataclass
class Contrato:
    id: str
    dominio: str
    nome: str
    versao: str
    dono: str
    descricao: str
    classificacao: str
    granularidade: str
    sla: dict
    esquema: list
    qualidade: list = field(default_factory=list)
    consumidores_autorizados: list = field(default_factory=list)
    origem: list = field(default_factory=list)

    @classmethod
    def carregar(cls, caminho: Path):
        dados = yaml.safe_load(Path(caminho).read_text(encoding="utf-8"))
        return cls(**dados)

    @property
    def versao_major(self):
        return "v" + self.versao.split(".")[0]


@dataclass
class Checagem:
    regra: str
    ok: bool
    detalhe: str = ""


def validar(contrato: Contrato, df: pd.DataFrame):
    resultados = []
    esperadas = [c["nome"] for c in contrato.esquema]
    faltando = [c for c in esperadas if c not in df.columns]
    extras = [c for c in df.columns if c not in esperadas]
    resultados.append(Checagem("esquema: colunas declaradas presentes", not faltando, ",".join(faltando)))
    resultados.append(Checagem("esquema: sem colunas não declaradas", not extras, ",".join(extras)))
    if faltando:
        return resultados

    for campo in contrato.esquema:
        nome, serie = campo["nome"], df[campo["nome"]]
        if not TIPOS_PANDAS[campo["tipo"]](serie):
            resultados.append(Checagem(f"tipo {nome}={campo['tipo']}", False, str(serie.dtype)))
        if campo.get("obrigatorio"):
            nulos = int(serie.isna().sum())
            resultados.append(Checagem(f"não nulo: {nome}", nulos == 0, f"{nulos} nulos"))
        if campo.get("unico"):
            dup = int(serie.duplicated().sum())
            resultados.append(Checagem(f"único: {nome}", dup == 0, f"{dup} duplicados"))
        if "valores" in campo:
            fora = int((~serie.dropna().isin(campo["valores"])).sum())
            resultados.append(Checagem(f"domínio de valores: {nome}", fora == 0, f"{fora} fora do dominio"))
        if "min" in campo:
            abaixo = int((serie.dropna() < campo["min"]).sum())
            resultados.append(Checagem(f"mínimo {campo['min']}: {nome}", abaixo == 0, f"{abaixo} abaixo"))
        if "max" in campo:
            acima = int((serie.dropna() > campo["max"]).sum())
            resultados.append(Checagem(f"máximo {campo['max']}: {nome}", acima == 0, f"{acima} acima"))

    minimo_linhas = contrato.sla.get("linhas_minimas", 1)
    resultados.append(Checagem(f"volume mínimo {minimo_linhas}", len(df) >= minimo_linhas, f"{len(df)} linhas"))

    if contrato.qualidade:
        con = duckdb.connect()
        con.register("produto", df)
        con.execute("SET enable_external_access = false")
        con.execute("SET lock_configuration = true")
        for regra in contrato.qualidade:
            if ";" in regra["condicao"]:
                raise ValueError(f"condicao com multiplas instrucoes: {regra['nome']}")
            violacoes = con.execute(f"SELECT count(*) FROM produto WHERE NOT ({regra['condicao']})").fetchone()[0]
            tolerancia = regra.get("tolerancia", 0.0)
            ok = violacoes <= tolerancia * len(df)
            resultados.append(Checagem(f"regra: {regra['nome']}", ok, f"{violacoes} violações"))
        con.close()
    return resultados
