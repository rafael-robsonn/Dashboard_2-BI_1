from pathlib import Path

import pandas as pd

from datamesh.plataforma import catalogo

AQUI = Path(__file__).parent
FONTES = AQUI / "fontes"
REDES = {"ads_google_ads.csv": "Google Ads", "ads_meta_ads.csv": "Meta Ads", "ads_tiktok_ads.csv": "TikTok Ads",
         "ads_e-mail.csv": "E-mail", "ads_push_app.csv": "Push App"}


def executar():
    cad = pd.read_csv(FONTES / "cadastro_campanhas.csv")
    campanhas = pd.DataFrame({
        "campanha_id": cad["campaign_id"], "nome": cad["campaign_name"], "rede": cad["network"],
        "inicio": pd.to_datetime(cad["start"]), "fim": pd.to_datetime(cad["end"]),
        "orcamento_diario_brl": cad["daily_budget"].astype(float)})
    catalogo.publicar(AQUI / "contratos" / "campanhas.yaml", campanhas)

    partes = []
    for arquivo, rede in REDES.items():
        df = pd.read_csv(FONTES / arquivo)
        partes.append(pd.DataFrame({
            "data": pd.to_datetime(df["date"]), "campanha_id": df["campaign_id"], "rede": rede,
            "investimento_brl": df["spend"].astype(float), "impressoes": df["impressions"].astype("int64"),
            "cliques": df["clicks"].astype("int64")}))
    investimento = pd.concat(partes, ignore_index=True).sort_values(["data", "campanha_id"])
    catalogo.publicar(AQUI / "contratos" / "investimento_diario.yaml", investimento)
