from pathlib import Path

import numpy as np
import pandas as pd

from datamesh.plataforma import catalogo
from datamesh.plataforma.governanca import pseudonimizar_cpf

AQUI = Path(__file__).parent
FONTES = AQUI / "fontes"


def _pesquisa():
    df = pd.read_csv(FONTES / "survey_nps_export.csv", dtype=str)
    return df.rename(columns={
        "Response ID": "resposta_id", "Submitted At": "respondido_em", "Email": "email", "CPF": "cpf",
        "Transaction": "pedido_id", "Store": "loja", "Q1 - De 0 a 10, quanto recomendaria?": "nota",
        "Q2 - Motivo principal": "motivo"})


def respostas_nps():
    df = _pesquisa()
    nota = df["nota"].astype(int)
    saida = pd.DataFrame({
        "resposta_id": df["resposta_id"],
        "respondido_em": pd.to_datetime(df["respondido_em"], format="%d/%m/%Y %H:%M"),
        "pedido_id": df["pedido_id"],
        "cliente_pid": pseudonimizar_cpf(df["cpf"]),
        "loja_id": df["loja"].str.replace("Loja ", "").replace("Online", "99").astype(int),
        "nota": nota,
        "classe_nps": np.select([nota >= 9, nota >= 7], ["promotor", "neutro"], "detrator"),
        "motivo": df["motivo"],
    })
    catalogo.publicar(AQUI / "contratos" / "respostas_nps.yaml", saida)


def tentativa_com_pii():
    df = _pesquisa()
    rascunho = pd.DataFrame({
        "resposta_id": df["resposta_id"],
        "respondido_em": pd.to_datetime(df["respondido_em"], format="%d/%m/%Y %H:%M"),
        "email": df["email"],
        "Loja": df["loja"],
        "nota": df["nota"].astype(int),
    })
    catalogo.publicar(AQUI / "contratos" / "respostas_nps_rascunho_v0.yaml", rascunho)


def perfil_cliente():
    crm = pd.read_csv(FONTES / "crm_cadastro_clientes.csv", sep=";", dtype={"cpf": str})
    idade = 2026 - crm["ano_nascimento"]
    saida = pd.DataFrame({
        "cliente_pid": pseudonimizar_cpf(crm["cpf"]),
        "faixa_etaria": pd.cut(idade, [0, 24, 34, 44, 59, 200], labels=["18 a 24", "25 a 34", "35 a 44", "45 a 59", "60+"]).astype(str),
        "ra": crm["ra"],
        "tier_fidelidade": crm["tier_fidelidade"],
        "consentimento_marketing": crm["consentimento_marketing"].astype(bool),
        "cliente_desde": pd.to_datetime(crm["data_cadastro"]),
    })
    catalogo.publicar(AQUI / "contratos" / "perfil_cliente.yaml", saida)


def executar():
    tentativa_com_pii()
    respostas_nps()
    perfil_cliente()
