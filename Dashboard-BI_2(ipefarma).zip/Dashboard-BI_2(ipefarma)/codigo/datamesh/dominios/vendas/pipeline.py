from pathlib import Path

import duckdb
import numpy as np

from datamesh.plataforma import catalogo
from datamesh.plataforma.governanca import pseudonimizar_cpf

AQUI = Path(__file__).parent


def executar():
    con = duckdb.connect()
    brutos = con.execute("""
        SELECT id_venda AS pedido_id,
               CAST(substr(ts, 1, 19) AS TIMESTAMP) AS data_hora,
               CAST(filial AS INTEGER) AS loja_id,
               origem AS canal,
               cpf_cliente,
               CAST(total_bruto AS DECIMAL(12, 2)) AS valor_bruto_brl,
               CAST(total_desconto AS DECIMAL(12, 2)) AS desconto_brl,
               CAST(qtd_itens AS INTEGER) AS qtd_itens,
               utm_campaign AS campanha_id
        FROM read_json(?, format = 'newline_delimited', columns = {
            evento: 'VARCHAR', id_venda: 'VARCHAR', ts: 'VARCHAR', filial: 'INTEGER', origem: 'VARCHAR',
            cpf_cliente: 'VARCHAR', total_bruto: 'DOUBLE', total_desconto: 'DOUBLE', qtd_itens: 'INTEGER',
            utm_campaign: 'VARCHAR'})
        WHERE evento = 'venda_finalizada'
        QUALIFY row_number() OVER (PARTITION BY id_venda ORDER BY ts DESC) = 1
    """, [str(AQUI / "fontes" / "pdv_eventos_*.jsonl")]).df()
    con.close()

    pedidos = brutos.assign(
        cliente_pid=pseudonimizar_cpf(brutos["cpf_cliente"]),
        data=brutos["data_hora"].dt.normalize(),
        valor_bruto_brl=brutos["valor_bruto_brl"].astype(float),
        desconto_brl=brutos["desconto_brl"].astype(float),
    ).drop(columns=["cpf_cliente"])
    pedidos["valor_liquido_brl"] = np.round(pedidos["valor_bruto_brl"] - pedidos["desconto_brl"], 2)
    pedidos = pedidos[["pedido_id", "data_hora", "data", "loja_id", "canal", "cliente_pid",
                       "valor_bruto_brl", "desconto_brl", "valor_liquido_brl", "qtd_itens", "campanha_id"]]
    catalogo.publicar(AQUI / "contratos" / "pedidos.yaml", pedidos)

    diario = (pedidos.groupby(["data", "loja_id", "canal"], as_index=False)
              .agg(pedidos=("pedido_id", "count"), receita_liquida_brl=("valor_liquido_brl", "sum")))
    diario["receita_liquida_brl"] = diario["receita_liquida_brl"].round(2)
    diario["ticket_medio_brl"] = (diario["receita_liquida_brl"] / diario["pedidos"]).round(2)
    catalogo.publicar(AQUI / "contratos" / "vendas_diarias_loja.yaml", diario)
