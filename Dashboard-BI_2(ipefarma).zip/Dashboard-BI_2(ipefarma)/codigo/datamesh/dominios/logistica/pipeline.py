import json
from pathlib import Path

import duckdb
import numpy as np
import pandas as pd

from datamesh.plataforma import catalogo

AQUI = Path(__file__).parent
FONTES = AQUI / "fontes"


def ruptura():
    con = duckdb.connect()
    df = con.execute("""
        WITH pos AS (
            SELECT CAST(substr(COD_FILIAL, 2) AS INTEGER) AS loja_id,
                   strptime(DT_POSICAO, '%Y%m%d')::DATE AS data,
                   CAST(COD_ITEM AS INTEGER) AS sku,
                   CAST(QTD_DISPONIVEL AS INTEGER) AS disponivel,
                   CAST(QTD_MINIMA AS INTEGER) AS minimo
            FROM read_csv(?, delim = ';', header = true, all_varchar = true)
        ), itens AS (
            SELECT CAST(sku AS INTEGER) AS sku, categoria
            FROM read_csv(?, delim = ';', header = true, all_varchar = true)
        )
        SELECT data, loja_id,
               count(*)::INTEGER AS skus_monitorados,
               count(*) FILTER (WHERE disponivel = 0)::INTEGER AS skus_em_ruptura,
               count(*) FILTER (WHERE disponivel < minimo)::INTEGER AS skus_abaixo_minimo,
               avg(CASE WHEN disponivel = 0 THEN 1 ELSE 0 END) AS taxa_ruptura,
               coalesce(avg(CASE WHEN disponivel = 0 THEN 1 ELSE 0 END) FILTER (WHERE categoria = 'MIP e antigripais'), 0) AS ruptura_antigripais
        FROM pos JOIN itens USING (sku)
        GROUP BY ALL
        ORDER BY data, loja_id
    """, [str(FONTES / "wms_posicao_estoque.csv"), str(FONTES / "wms_itens_monitorados.csv")]).df()
    con.close()
    df["data"] = pd.to_datetime(df["data"])
    catalogo.publicar(AQUI / "contratos" / "ruptura_diaria_loja.yaml", df)


def entregas():
    bruto = json.loads((FONTES / "tms_entregas.json").read_text(encoding="utf-8"))["items"]
    df = pd.json_normalize(bruto)
    saida = pd.DataFrame({
        "envio_id": df["shipment.id"],
        "pedido_id": df["shipment.order_ref"],
        "servico": df["shipment.service"].map({"EXPRESS_4H": "Expressa 4h", "STANDARD_24H": "Padrão 24h"}),
        "ra_destino": df["destination.district"],
        "prometido_em": pd.to_datetime(df["promised_at"]),
        "entregue_em": pd.to_datetime(df["delivered_at"], format="ISO8601"),
        "status": df["status"].map({"DELIVERED": "entregue", "LOST": "extraviado"}),
    })
    saida["entregue_em"] = saida["entregue_em"].dt.floor("s")
    saida["atraso_min"] = np.round((saida["entregue_em"] - saida["prometido_em"]).dt.total_seconds() / 60, 1)
    saida["no_prazo"] = (saida["atraso_min"] <= 0).fillna(False).astype(bool)
    catalogo.publicar(AQUI / "contratos" / "entregas.yaml", saida)


def executar():
    ruptura()
    entregas()
