import sys
from pathlib import Path

RAIZ = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(RAIZ))

from datamesh.dominios.clientes import pipeline as clientes  # noqa: E402
from datamesh.dominios.logistica import pipeline as logistica  # noqa: E402
from datamesh.dominios.marketing import pipeline as marketing  # noqa: E402
from datamesh.dominios.vendas import pipeline as vendas  # noqa: E402
from datamesh.plataforma import catalogo  # noqa: E402

if __name__ == "__main__":
    if catalogo.CATALOGO.exists():
        catalogo.CATALOGO.unlink()
    for nome, dominio in [("vendas", vendas), ("logistica", logistica), ("clientes", clientes), ("marketing", marketing)]:
        print(f"dominio {nome}")
        dominio.executar()
