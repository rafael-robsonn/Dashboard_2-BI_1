# Data Mart e Data Mesh: Ipê Farma (dados sintéticos)

Requisitos: Python 3.11+, `pip install pandas numpy duckdb pyarrow pyyaml`.

```bash
python datamart/gerar_fontes.py
python datamart/etl.py
python dashboards/exportar_mart.py

python datamesh/gerar_fontes.py
export MESH_PSEUDO_KEY=$(python -c 'import secrets;print(secrets.token_hex(32))')
python datamesh/rodar_mesh.py
python datamesh/consumo/analises.py

python dashboards/build.py
```

Semente fixa: os números do relatório se reproduzem. Os dados brutos, o banco DuckDB e os Parquet não vão no zip porque são regenerados pelos scripts.
