CREATE SCHEMA IF NOT EXISTS stg;
CREATE SCHEMA IF NOT EXISTS mart;
CREATE SCHEMA IF NOT EXISTS audit;

CREATE TABLE IF NOT EXISTS audit.carga (
    carga_id      INTEGER,
    etapa         VARCHAR,
    regra         VARCHAR,
    linhas        BIGINT,
    resultado     VARCHAR,
    registrado_em TIMESTAMP DEFAULT current_timestamp
);

CREATE OR REPLACE TABLE mart.dim_tempo (
    sk_data             INTEGER PRIMARY KEY,
    data                DATE NOT NULL,
    dia                 TINYINT,
    mes                 TINYINT,
    nome_mes            VARCHAR,
    trimestre           TINYINT,
    ano                 SMALLINT,
    ano_mes             VARCHAR,
    dia_semana          TINYINT,
    nome_dia_semana     VARCHAR,
    fim_de_semana       BOOLEAN,
    semana_black_friday BOOLEAN
);

CREATE OR REPLACE TABLE mart.dim_hora (
    sk_hora TINYINT PRIMARY KEY,
    hora    TINYINT,
    periodo VARCHAR
);

CREATE OR REPLACE TABLE mart.dim_loja (
    sk_loja     INTEGER PRIMARY KEY,
    loja_id     INTEGER NOT NULL,
    nome        VARCHAR,
    regiao      VARCHAR,
    ra          VARCHAR,
    tipo        VARCHAR,
    inauguracao DATE
);

CREATE OR REPLACE TABLE mart.dim_produto (
    sk_produto  INTEGER PRIMARY KEY,
    sku         INTEGER NOT NULL,
    nome        VARCHAR,
    categoria   VARCHAR,
    marca       VARCHAR,
    controlado  BOOLEAN,
    faixa_preco VARCHAR
);

CREATE OR REPLACE TABLE mart.dim_cliente (
    sk_cliente              INTEGER PRIMARY KEY,
    cliente_id              INTEGER,
    faixa_etaria            VARCHAR,
    sexo                    VARCHAR,
    ra                      VARCHAR,
    tier_fidelidade         VARCHAR,
    consentimento_marketing BOOLEAN
);

CREATE OR REPLACE TABLE mart.dim_canal (
    sk_canal INTEGER PRIMARY KEY,
    canal    VARCHAR,
    tipo     VARCHAR
);

CREATE OR REPLACE TABLE mart.dim_pagamento (
    sk_pagamento INTEGER PRIMARY KEY,
    forma        VARCHAR
);

CREATE OR REPLACE TABLE mart.fato_vendas (
    sk_data         INTEGER REFERENCES mart.dim_tempo (sk_data),
    sk_hora         TINYINT REFERENCES mart.dim_hora (sk_hora),
    sk_loja         INTEGER REFERENCES mart.dim_loja (sk_loja),
    sk_produto      INTEGER REFERENCES mart.dim_produto (sk_produto),
    sk_cliente      INTEGER REFERENCES mart.dim_cliente (sk_cliente),
    sk_canal        INTEGER REFERENCES mart.dim_canal (sk_canal),
    sk_pagamento    INTEGER REFERENCES mart.dim_pagamento (sk_pagamento),
    pedido_id       BIGINT NOT NULL,
    quantidade      INTEGER NOT NULL,
    receita_bruta   DECIMAL(14, 2) NOT NULL,
    desconto        DECIMAL(14, 2) NOT NULL,
    receita_liquida DECIMAL(14, 2) NOT NULL,
    custo           DECIMAL(14, 2) NOT NULL,
    margem_bruta    DECIMAL(14, 2) NOT NULL,
    devolucao       BOOLEAN NOT NULL
);

CREATE OR REPLACE TABLE mart.fato_meta_mensal (
    sk_loja      INTEGER REFERENCES mart.dim_loja (sk_loja),
    ano_mes      VARCHAR NOT NULL,
    meta_receita DECIMAL(14, 2) NOT NULL
);
