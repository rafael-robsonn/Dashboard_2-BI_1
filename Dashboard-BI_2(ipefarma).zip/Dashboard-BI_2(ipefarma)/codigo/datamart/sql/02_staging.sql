CREATE OR REPLACE TABLE stg.pedidos AS
SELECT DISTINCT
    CAST(pedido_id AS BIGINT)                       AS pedido_id,
    strptime(data_hora, '%d/%m/%Y %H:%M:%S')        AS data_hora,
    CAST(loja_id AS INTEGER)                        AS loja_id,
    trim(canal)                                     AS canal,
    TRY_CAST(cliente_id AS INTEGER)                 AS cliente_id,
    trim(forma_pagamento)                           AS forma_pagamento,
    upper(trim(status))                             AS status
FROM read_csv(getvariable('dir_fontes') || '/pdv_pedidos.csv', delim = ';', header = true, all_varchar = true);

CREATE OR REPLACE TABLE stg.itens AS
SELECT
    CAST(item_id AS BIGINT)                                   AS item_id,
    CAST(pedido_id AS BIGINT)                                 AS pedido_id,
    CAST(sku AS INTEGER)                                      AS sku,
    CAST(quantidade AS INTEGER)                               AS quantidade,
    CAST(replace(preco_unitario, ',', '.') AS DECIMAL(12, 2)) AS preco_unitario,
    CAST(replace(percentual_desconto, ',', '.') AS DOUBLE)    AS percentual_desconto,
    CAST(replace(custo_unitario, ',', '.') AS DECIMAL(12, 2)) AS custo_unitario
FROM read_csv(getvariable('dir_fontes') || '/pdv_itens_pedido.csv', delim = ';', header = true, all_varchar = true);

CREATE OR REPLACE TABLE stg.produtos AS
SELECT
    CAST(sku AS INTEGER)                               AS sku,
    nome, categoria, marca,
    CAST(replace(preco_base, ',', '.') AS DOUBLE)      AS preco_base,
    lower(controlado) = 'true'                         AS controlado
FROM read_csv(getvariable('dir_fontes') || '/erp_produtos.csv', delim = ';', header = true, all_varchar = true);

CREATE OR REPLACE TABLE stg.lojas AS
SELECT CAST(loja_id AS INTEGER) AS loja_id, nome, regiao, ra, CAST(inauguracao AS DATE) AS inauguracao
FROM read_csv(getvariable('dir_fontes') || '/erp_lojas.csv', delim = ';', header = true, all_varchar = true);

CREATE OR REPLACE TABLE stg.clientes AS
SELECT
    CAST(cliente_id AS INTEGER)            AS cliente_id,
    sexo,
    CAST(ano_nascimento AS INTEGER)        AS ano_nascimento,
    ra,
    tier_fidelidade,
    lower(consentimento_marketing) = 'true' AS consentimento_marketing
FROM read_csv(getvariable('dir_fontes') || '/crm_clientes.csv', delim = ';', header = true, all_varchar = true);

CREATE OR REPLACE TABLE stg.metas AS
SELECT ano_mes, CAST(loja_id AS INTEGER) AS loja_id, CAST(replace(meta_receita, ',', '.') AS DECIMAL(14, 2)) AS meta_receita
FROM read_csv(getvariable('dir_fontes') || '/plan_metas_mensais.csv', delim = ';', header = true, all_varchar = true);
