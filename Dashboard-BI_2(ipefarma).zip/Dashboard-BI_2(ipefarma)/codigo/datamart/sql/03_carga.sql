INSERT INTO mart.dim_tempo
WITH dias AS (
    SELECT CAST(d AS DATE) AS data
    FROM range(DATE '2024-01-01', DATE '2026-07-01', INTERVAL 1 DAY) t(d)
), bf AS (
    SELECT ano, max(data) AS sexta
    FROM (SELECT year(data) AS ano, data FROM dias WHERE month(data) = 11 AND isodow(data) = 5)
    GROUP BY ano
)
SELECT
    CAST(strftime(d.data, '%Y%m%d') AS INTEGER),
    d.data, day(d.data), month(d.data),
    ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'][month(d.data)],
    quarter(d.data), year(d.data), strftime(d.data, '%Y-%m'),
    isodow(d.data),
    ['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'][isodow(d.data)],
    isodow(d.data) >= 6,
    d.data BETWEEN bf.sexta - 3 AND bf.sexta + 3
FROM dias d
LEFT JOIN bf ON bf.ano = year(d.data);

INSERT INTO mart.dim_hora
SELECT h, h,
    CASE WHEN h < 6 THEN 'Madrugada' WHEN h < 12 THEN 'Manhã' WHEN h < 18 THEN 'Tarde' ELSE 'Noite' END
FROM range(0, 24) t(h);

INSERT INTO mart.dim_loja
SELECT row_number() OVER (ORDER BY loja_id), loja_id, nome, regiao, ra,
    CASE WHEN loja_id = 99 THEN 'Digital' ELSE 'Física' END, inauguracao
FROM stg.lojas;

INSERT INTO mart.dim_produto
SELECT row_number() OVER (ORDER BY sku), sku, nome, categoria, marca, controlado,
    CASE WHEN preco_base < 20 THEN 'Até R$ 20'
         WHEN preco_base < 60 THEN 'R$ 20 a 60'
         WHEN preco_base < 150 THEN 'R$ 60 a 150'
         ELSE 'Acima de R$ 150' END
FROM stg.produtos;

INSERT INTO mart.dim_cliente VALUES (-1, NULL, 'Não identificado', 'N/I', 'N/I', 'Sem cadastro', false);
INSERT INTO mart.dim_cliente
SELECT row_number() OVER (ORDER BY cliente_id), cliente_id,
    CASE WHEN 2026 - ano_nascimento < 25 THEN '18 a 24'
         WHEN 2026 - ano_nascimento < 35 THEN '25 a 34'
         WHEN 2026 - ano_nascimento < 45 THEN '35 a 44'
         WHEN 2026 - ano_nascimento < 60 THEN '45 a 59'
         ELSE '60+' END,
    sexo, ra, tier_fidelidade, consentimento_marketing
FROM stg.clientes;

INSERT INTO mart.dim_canal
SELECT row_number() OVER (ORDER BY canal), canal, CASE WHEN canal = 'Loja física' THEN 'Presencial' ELSE 'Digital' END
FROM (SELECT DISTINCT canal FROM stg.pedidos);

INSERT INTO mart.dim_pagamento
SELECT row_number() OVER (ORDER BY forma_pagamento), forma_pagamento
FROM (SELECT DISTINCT forma_pagamento FROM stg.pedidos);

INSERT INTO mart.fato_vendas
SELECT
    CAST(strftime(p.data_hora, '%Y%m%d') AS INTEGER),
    hour(p.data_hora),
    l.sk_loja,
    pr.sk_produto,
    coalesce(c.sk_cliente, -1),
    ca.sk_canal,
    pg.sk_pagamento,
    p.pedido_id,
    i.quantidade,
    round(i.quantidade * i.preco_unitario, 2),
    round(i.quantidade * i.preco_unitario * i.percentual_desconto, 2),
    round(i.quantidade * i.preco_unitario * (1 - i.percentual_desconto), 2),
    round(i.quantidade * i.custo_unitario, 2),
    round(i.quantidade * i.preco_unitario * (1 - i.percentual_desconto) - i.quantidade * i.custo_unitario, 2),
    i.quantidade < 0
FROM stg.itens i
JOIN stg.pedidos p        ON p.pedido_id = i.pedido_id AND p.status = 'CONCLUIDO'
JOIN mart.dim_loja l      ON l.loja_id = p.loja_id
JOIN mart.dim_produto pr  ON pr.sku = i.sku
LEFT JOIN mart.dim_cliente c ON c.cliente_id = p.cliente_id
JOIN mart.dim_canal ca    ON ca.canal = p.canal
JOIN mart.dim_pagamento pg ON pg.forma = p.forma_pagamento;

INSERT INTO mart.fato_meta_mensal
SELECT l.sk_loja, m.ano_mes, m.meta_receita
FROM stg.metas m JOIN mart.dim_loja l ON l.loja_id = m.loja_id;

CREATE OR REPLACE VIEW mart.vw_vendas_mensal_loja AS
SELECT t.ano_mes, l.loja_id, l.nome AS loja, l.regiao, ca.canal,
       count(DISTINCT f.pedido_id)      AS pedidos,
       sum(f.receita_liquida)           AS receita,
       sum(f.margem_bruta)              AS margem
FROM mart.fato_vendas f
JOIN mart.dim_tempo t  USING (sk_data)
JOIN mart.dim_loja l   USING (sk_loja)
JOIN mart.dim_canal ca USING (sk_canal)
GROUP BY ALL;

CREATE OR REPLACE VIEW mart.vw_atingimento_meta AS
WITH real AS (
    SELECT t.ano_mes, f.sk_loja, sum(f.receita_liquida) AS receita
    FROM mart.fato_vendas f JOIN mart.dim_tempo t USING (sk_data)
    GROUP BY ALL
)
SELECT m.ano_mes, l.loja_id, l.nome AS loja, l.regiao, coalesce(r.receita, 0) AS receita, m.meta_receita,
       coalesce(r.receita, 0) / m.meta_receita AS atingimento
FROM mart.fato_meta_mensal m
JOIN mart.dim_loja l USING (sk_loja)
LEFT JOIN real r ON r.ano_mes = m.ano_mes AND r.sk_loja = m.sk_loja;

CREATE OR REPLACE VIEW mart.vw_categoria AS
SELECT t.ano, pr.categoria,
       sum(f.receita_liquida) AS receita, sum(f.margem_bruta) AS margem,
       sum(f.margem_bruta) / nullif(sum(f.receita_liquida), 0) AS margem_pct,
       sum(f.quantidade) AS unidades
FROM mart.fato_vendas f
JOIN mart.dim_tempo t USING (sk_data)
JOIN mart.dim_produto pr USING (sk_produto)
GROUP BY ALL;
