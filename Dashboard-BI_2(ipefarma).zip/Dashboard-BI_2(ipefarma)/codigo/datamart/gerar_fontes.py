import sys
from pathlib import Path

import numpy as np
import pandas as pd

RAIZ = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(RAIZ))
from comum import mundo  # noqa: E402

SAIDA = Path(__file__).parent / "fontes"
INICIO, FIM = pd.Timestamp("2024-01-01"), pd.Timestamp("2026-06-30")

SAZONAL_MES = np.array([0.92, 0.90, 0.98, 1.00, 1.05, 1.10, 1.12, 1.08, 1.02, 1.00, 1.06, 1.15])
FATOR_DIA_SEMANA = np.array([1.02, 0.97, 0.98, 1.00, 1.08, 1.18, 0.77])
TENDENCIA_LOJA = {17: -0.09, 14: -0.02, 5: 0.08, 3: 0.05, 12: 0.07}
AMBICAO_META = {17: 1.12, 6: 1.25, 14: 1.08, 1: 1.04, 5: 1.03}


def norm(v):
    v = np.asarray(v, dtype=float)
    return v / v.sum()


def black_friday(ano):
    nov = pd.date_range(f"{ano}-11-01", f"{ano}-11-30")
    sextas = nov[nov.weekday == 4]
    return sextas[-1]


def fator_evento(datas):
    f = np.ones(len(datas))
    for ano in range(INICIO.year, FIM.year + 1):
        bf = black_friday(ano)
        janela = (datas >= bf - pd.Timedelta(days=3)) & (datas <= bf + pd.Timedelta(days=3))
        f[janela] *= 1.30
        natal = (datas >= pd.Timestamp(f"{ano}-12-15")) & (datas <= pd.Timestamp(f"{ano}-12-24"))
        f[natal] *= 1.18
    return f


def lambda_diaria(lojas, datas):
    anos = (datas - INICIO).days.values / 365.25
    base = SAZONAL_MES[datas.month - 1] * FATOR_DIA_SEMANA[datas.weekday] * fator_evento(datas)
    linhas = {}
    for loja in lojas.itertuples():
        if loja.loja_id == 99:
            lam = 70 * base * (1 + 0.55 * anos) * (1 + 0.08 * (datas.weekday < 5))
        else:
            ativa = (datas >= loja.inauguracao).astype(float)
            idade = np.clip((datas - loja.inauguracao).days.values / 180, 0, 1)
            rampa = np.where(loja.inauguracao > INICIO, 0.45 + 0.55 * idade, 1.0)
            lam = 26 * loja.porte * base * (1 + 0.05 * anos) * (1 + TENDENCIA_LOJA.get(loja.loja_id, 0) * anos) * rampa * ativa
        linhas[loja.loja_id] = lam
    return pd.DataFrame(linhas, index=datas)


def pesos_categoria(mes, bf_semana):
    cats = list(mundo.CATEGORIAS)
    p = np.array([mundo.CATEGORIAS[c]["peso"] for c in cats])
    if mes in (5, 6, 7, 8):
        p[cats.index("MIP e antigripais")] *= 1.65
    if mes in (11, 12) or bf_semana:
        p[cats.index("Dermocosméticos")] *= 1.7 if bf_semana else 1.3
        p[cats.index("Perfumaria")] *= 2.2 if bf_semana else 1.6
    if mes in (1, 2):
        p[cats.index("Suplementos e vitaminas")] *= 1.35
    return p / p.sum()


def main():
    rng = np.random.default_rng(mundo.SEED + 10)
    SAIDA.mkdir(parents=True, exist_ok=True)
    lojas = mundo.lojas()
    produtos = mundo.produtos()
    clientes = mundo.clientes()
    datas = pd.date_range(INICIO, FIM, freq="D")

    lam = lambda_diaria(lojas, datas)
    contagens = rng.poisson(lam.values)
    dia_idx, loja_col = np.nonzero(contagens)
    reps = contagens[dia_idx, loja_col]
    dia_idx = np.repeat(dia_idx, reps)
    loja_ids = lam.columns.values[np.repeat(loja_col, reps)]
    n = len(dia_idx)
    datas_ped = datas[dia_idx]
    digital = loja_ids == 99

    anos = (datas_ped - INICIO).days.values / 365.25
    prob_app = np.clip(0.35 + 0.16 * anos, 0, 0.78)
    canal = np.where(digital, np.where(rng.random(n) < prob_app, "App", "Site"), "Loja física")

    hora_loja = rng.choice(np.arange(7, 23), n, p=norm([2, 4, 6, 7, 8, 9, 8, 6, 6, 7, 8, 9, 8, 6, 4, 2]))
    hora_dig = rng.choice(np.arange(24), n, p=norm([1, .5, .4, .3, .3, .5, 1.5, 3, 4.5, 5, 5.5, 6, 6.5, 5.5, 5, 5, 5.2, 5.8, 6.4, 7.4, 7.8, 6.6, 4.5, 2.3]))
    hora = np.where(digital, hora_dig, hora_loja)
    ts = datas_ped + pd.to_timedelta(hora, unit="h") + pd.to_timedelta(rng.integers(0, 3600, n), unit="s")

    aff = clientes["afinidade"].values / clientes["afinidade"].sum()
    cli = rng.choice(clientes["cliente_id"].values, n, p=aff).astype(float)
    identificado = digital | (rng.random(n) < 0.64)
    cli[~identificado] = np.nan

    p_pix = np.clip(0.22 + 0.10 * anos, 0, 0.55)
    u = rng.random(n)
    pagamento = np.select(
        [u < p_pix, u < p_pix + 0.30, u < p_pix + 0.30 + np.clip(0.26 - 0.06 * anos, 0.08, 1), u < 0.96],
        ["Pix", "Cartão de crédito", "Cartão de débito", "Convênio"], "Dinheiro")
    pagamento = np.where(digital & (pagamento == "Dinheiro"), "Pix", pagamento)
    pagamento = np.where(digital & (pagamento == "Convênio"), "Cartão de crédito", pagamento)

    status = np.where(rng.random(n) < np.where(digital, 0.045, 0.012), "CANCELADO", "CONCLUIDO")
    pedidos = pd.DataFrame(dict(
        pedido_id=np.arange(1_000_001, 1_000_001 + n), data_hora=ts, loja_id=loja_ids, canal=canal,
        cliente_id=cli, forma_pagamento=pagamento, status=status))
    pedidos = pedidos.sort_values("data_hora").reset_index(drop=True)
    pedidos["pedido_id"] = np.arange(1_000_001, 1_000_001 + n)

    n_itens = np.where(pedidos["canal"].values == "Loja física", 1 + rng.poisson(0.9, n), 1 + rng.poisson(1.8, n))
    ped_rep = np.repeat(np.arange(n), n_itens)
    m = len(ped_rep)
    dt_item = pedidos["data_hora"].values[ped_rep].astype("datetime64[D]")
    meses = pd.DatetimeIndex(dt_item).month.values
    bf_flag = np.zeros(m, dtype=bool)
    for ano in range(INICIO.year, FIM.year + 1):
        bf = black_friday(ano).to_datetime64()
        bf_flag |= (dt_item >= bf - np.timedelta64(3, "D")) & (dt_item <= bf + np.timedelta64(3, "D"))

    cats = list(mundo.CATEGORIAS)
    cat_idx = np.empty(m, dtype=int)
    for mes in range(1, 13):
        for bf in (False, True):
            sel = (meses == mes) & (bf_flag == bf)
            if sel.any():
                cat_idx[sel] = rng.choice(len(cats), sel.sum(), p=pesos_categoria(mes, bf))
    sku = np.empty(m, dtype=int)
    for i, cat in enumerate(cats):
        sel = cat_idx == i
        sub = produtos[produtos.categoria == cat]
        sku[sel] = rng.choice(sub["sku"].values, sel.sum(), p=sub["popularidade"].values)

    prod = produtos.set_index("sku")
    anos_item = (pd.DatetimeIndex(dt_item) - INICIO).days.values / 365.25
    inflacao = (1.045 ** anos_item)
    preco_tabela = np.round(prod.loc[sku, "preco_base"].values * inflacao, 2)
    custo = np.round(prod.loc[sku, "custo_base"].values * inflacao * rng.normal(1, 0.02, m), 2)
    canal_item = pedidos["canal"].values[ped_rep]
    desc = rng.choice([0, 0, 0, 0.05, 0.10, 0.15], m)
    desc = np.where(canal_item == "App", np.maximum(desc, rng.choice([0.05, 0.10], m)), desc)
    desc = np.where(bf_flag, np.maximum(desc, rng.choice([0.15, 0.20, 0.25], m)), desc)
    qtd = rng.choice([1, 1, 1, 1, 1, 2, 2, 3], m)
    devolucao = rng.random(m) < 0.0018
    qtd = np.where(devolucao, -1, qtd)

    itens = pd.DataFrame(dict(
        item_id=np.arange(1, m + 1), pedido_id=pedidos["pedido_id"].values[ped_rep], sku=sku,
        quantidade=qtd, preco_unitario=preco_tabela, percentual_desconto=desc, custo_unitario=custo))

    dup = pedidos.sample(frac=0.003, random_state=1)
    pedidos_export = pd.concat([pedidos, dup]).sort_values("pedido_id")
    pedidos_export["data_hora"] = pedidos_export["data_hora"].dt.strftime("%d/%m/%Y %H:%M:%S")
    pedidos_export["cliente_id"] = pedidos_export["cliente_id"].astype("Int64")

    ped_valor = itens.assign(v=itens.quantidade * itens.preco_unitario * (1 - itens.percentual_desconto)).groupby("pedido_id")["v"].sum()
    tmp = pedidos.assign(valor=pedidos["pedido_id"].map(ped_valor), mes=pedidos["data_hora"].dt.to_period("M"))
    ticket_mes = tmp.groupby(["mes", "canal"])["valor"].mean()
    lam_m = lam.groupby(lam.index.to_period("M")).sum()
    metas = []
    for mes, linha in lam_m.iterrows():
        for loja_id, esperado in linha.items():
            if esperado <= 0:
                continue
            canal_ref = "Site" if loja_id == 99 else "Loja física"
            t = ticket_mes.get((mes, canal_ref), ticket_mes.xs(mes, level=0).mean())
            amb = AMBICAO_META.get(loja_id, rng.uniform(0.95, 1.01))
            metas.append(dict(ano_mes=str(mes), loja_id=loja_id, meta_receita=round(float(esperado * t * amb), -2)))

    cli_export = clientes.drop(columns=["afinidade"])
    cli_export["data_cadastro"] = cli_export["data_cadastro"].dt.strftime("%Y-%m-%d")
    lojas.drop(columns=["porte"]).assign(inauguracao=lambda d: d.inauguracao.dt.strftime("%Y-%m-%d")).to_csv(SAIDA / "erp_lojas.csv", sep=";", index=False)
    produtos.drop(columns=["popularidade"]).to_csv(SAIDA / "erp_produtos.csv", sep=";", decimal=",", index=False)
    cli_export.to_csv(SAIDA / "crm_clientes.csv", sep=";", index=False)
    pedidos_export.to_csv(SAIDA / "pdv_pedidos.csv", sep=";", index=False)
    itens.to_csv(SAIDA / "pdv_itens_pedido.csv", sep=";", decimal=",", index=False)
    pd.DataFrame(metas).to_csv(SAIDA / "plan_metas_mensais.csv", sep=";", decimal=",", index=False)

    print(f"pedidos: {len(pedidos_export):,} (com {len(dup)} duplicados)")
    print(f"itens: {len(itens):,}")
    print(f"clientes: {len(cli_export):,} | produtos: {len(produtos)} | lojas: {len(lojas)} | metas: {len(metas)}")


if __name__ == "__main__":
    main()
