import sys
import time
from pathlib import Path

import duckdb

BASE = Path(__file__).parent
BANCO = BASE / "datamart_comercial.duckdb"
FONTES = BASE / "fontes"
SQL = BASE / "sql"

CHECAGENS = [
    ("staging", "pedido_id único após deduplicação",
     "SELECT count(*) - count(DISTINCT pedido_id) FROM stg.pedidos", 0),
    ("staging", "itens órfãos (sem pedido)",
     "SELECT count(*) FROM stg.itens i LEFT JOIN stg.pedidos p USING (pedido_id) WHERE p.pedido_id IS NULL", 0),
    ("staging", "SKU inexistente no cadastro",
     "SELECT count(*) FROM stg.itens i LEFT JOIN stg.produtos p USING (sku) WHERE p.sku IS NULL", 0),
    ("staging", "preço não positivo",
     "SELECT count(*) FROM stg.itens WHERE preco_unitario <= 0", 0),
    ("staging", "desconto fora de [0, 0.5]",
     "SELECT count(*) FROM stg.itens WHERE percentual_desconto NOT BETWEEN 0 AND 0.5", 0),
    ("mart", "fato sem data válida",
     "SELECT count(*) FROM mart.fato_vendas f LEFT JOIN mart.dim_tempo t USING (sk_data) WHERE t.sk_data IS NULL", 0),
    ("mart", "margem inconsistente",
     "SELECT count(*) FROM mart.fato_vendas WHERE abs(receita_liquida - custo - margem_bruta) > 0.02", 0),
    ("mart", "receita conciliada com staging",
     """SELECT round(abs((SELECT sum(receita_liquida) FROM mart.fato_vendas) -
        (SELECT sum(round(i.quantidade * i.preco_unitario * (1 - i.percentual_desconto), 2))
         FROM stg.itens i JOIN stg.pedidos p USING (pedido_id) WHERE p.status = 'CONCLUIDO')), 0)""", 0),
]

INFORMATIVOS = [
    ("staging", "duplicatas removidas em pedidos",
     "SELECT (SELECT count(*) FROM read_csv(getvariable('dir_fontes') || '/pdv_pedidos.csv', delim=';', header=true)) - (SELECT count(*) FROM stg.pedidos)"),
    ("staging", "pedidos cancelados excluídos", "SELECT count(*) FROM stg.pedidos WHERE status = 'CANCELADO'"),
    ("mart", "devoluções mantidas com sinal negativo", "SELECT count(*) FROM mart.fato_vendas WHERE devolucao"),
    ("mart", "linhas na fato_vendas", "SELECT count(*) FROM mart.fato_vendas"),
]


def executar_arquivo(con, nome):
    con.execute((SQL / nome).read_text(encoding="utf-8"))


def main():
    if BANCO.exists():
        BANCO.unlink()
    con = duckdb.connect(str(BANCO))
    con.execute("SET VARIABLE dir_fontes = ?", [str(FONTES)])
    inicio = time.perf_counter()

    executar_arquivo(con, "01_schema.sql")
    executar_arquivo(con, "02_staging.sql")

    carga_id = 1
    falhas = []

    def rodar(etapa):
        for e, regra, sql, esperado in CHECAGENS:
            if e != etapa:
                continue
            valor = con.execute(sql).fetchone()[0]
            ok = valor == esperado
            con.execute("INSERT INTO audit.carga VALUES (?, ?, ?, ?, ?, current_timestamp)",
                        [carga_id, e, regra, int(valor), "OK" if ok else "FALHA"])
            print(f"  [{'OK' if ok else 'FALHA'}] {regra}: {valor}")
            if not ok:
                falhas.append(regra)
        for e, regra, sql in INFORMATIVOS:
            if e == etapa:
                valor = con.execute(sql).fetchone()[0]
                con.execute("INSERT INTO audit.carga VALUES (?, ?, ?, ?, 'INFO', current_timestamp)", [carga_id, e, regra, int(valor)])
                print(f"  [INFO] {regra}: {valor:,}")

    print("staging")
    rodar("staging")
    if falhas:
        con.close()
        sys.exit(f"carga abortada: {falhas}")

    executar_arquivo(con, "03_carga.sql")
    print("mart")
    rodar("mart")
    if falhas:
        con.close()
        sys.exit(f"carga abortada: {falhas}")

    con.execute("DROP SCHEMA stg CASCADE")
    con.execute("CHECKPOINT")
    con.close()
    print(f"concluido em {time.perf_counter() - inicio:.1f}s -> {BANCO.name}")


if __name__ == "__main__":
    main()
