from pathlib import Path
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b = p.chromium.launch()
    for nome in ["mart", "estrela", "mesh"]:
        pg = b.new_page(viewport={"width": 1600, "height": 800}, device_scale_factor=2)
        pg.goto(Path(f"{nome}.html").resolve().as_uri()); pg.wait_for_timeout(400)
        pg.locator(".tela").screenshot(path=f"../img/diag_{nome}.png")
    b.close()
