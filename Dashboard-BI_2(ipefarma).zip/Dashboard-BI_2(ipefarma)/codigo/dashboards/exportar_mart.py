import json
from pathlib import Path

import duckdb

RAIZ = Path(__file__).resolve().parents[1]
BANCO = RAIZ / "datamart" / "datamart_comercial.duckdb"
SAIDA = Path(__file__).parent / "dados_mart.json"


def main():
    con = duckdb.connect(str(BANCO), read_only=True)

    def tab(sql):
        rel = con.execute(sql)
        cols = [d[0] for d in rel.description]
        linhas = [[float(v) if hasattr(v, "as_integer_ratio") and not isinstance(v, int) else v for v in r] for r in rel.fetchall()]
        return {"colunas": cols, "linhas": linhas}

    dados = {
        "lojas": tab("SELECT loja_id, nome, regiao, tipo FROM mart.dim_loja ORDER BY loja_id"),
        "categorias": tab("""
            SELECT t.ano_mes, l.loja_id, ca.canal, pr.categoria,
                   round(sum(f.receita_liquida), 2), round(sum(f.margem_bruta), 2), sum(f.quantidade)
            FROM mart.fato_vendas f
            JOIN mart.dim_tempo t USING (sk_data) JOIN mart.dim_loja l USING (sk_loja)
            JOIN mart.dim_canal ca USING (sk_canal) JOIN mart.dim_produto pr USING (sk_produto)
            GROUP BY ALL ORDER BY 1, 2, 3, 4"""),
        "pedidos": tab("""
            SELECT t.ano_mes, l.loja_id, ca.canal,
                   count(DISTINCT f.pedido_id), round(sum(f.receita_liquida), 2), round(sum(f.desconto), 2),
                   count(DISTINCT f.sk_cliente) FILTER (WHERE f.sk_cliente > 0)
            FROM mart.fato_vendas f
            JOIN mart.dim_tempo t USING (sk_data) JOIN mart.dim_loja l USING (sk_loja) JOIN mart.dim_canal ca USING (sk_canal)
            GROUP BY ALL ORDER BY 1, 2, 3"""),
        "metas": tab("""
            SELECT m.ano_mes, l.loja_id, m.meta_receita FROM mart.fato_meta_mensal m JOIN mart.dim_loja l USING (sk_loja)"""),
        "calor": tab("""
            SELECT t.ano, ca.canal, t.dia_semana, f.sk_hora, count(DISTINCT f.pedido_id)
            FROM mart.fato_vendas f JOIN mart.dim_tempo t USING (sk_data) JOIN mart.dim_canal ca USING (sk_canal)
            GROUP BY ALL"""),
        "pagamentos": tab("""
            SELECT t.ano, t.trimestre, ca.canal, pg.forma, round(sum(f.receita_liquida), 2)
            FROM mart.fato_vendas f JOIN mart.dim_tempo t USING (sk_data)
            JOIN mart.dim_canal ca USING (sk_canal) JOIN mart.dim_pagamento pg USING (sk_pagamento)
            GROUP BY ALL ORDER BY 1, 2"""),
        "auditoria": tab("SELECT etapa, regra, linhas, resultado FROM audit.carga ORDER BY registrado_em"),
    }
    con.close()
    SAIDA.write_text(json.dumps(dados, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    print(f"{SAIDA.name}: {SAIDA.stat().st_size / 1024:.0f} KB")


if __name__ == "__main__":
    main()
