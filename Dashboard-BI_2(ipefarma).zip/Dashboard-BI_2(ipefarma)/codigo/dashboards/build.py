import json
from pathlib import Path

AQUI = Path(__file__).parent
CHART = (AQUI / "chart.umd.js").read_text(encoding="utf-8")
FONTE = (AQUI / "archivo.b64").read_text().strip()


def montar(template, dados, saida):
    html = (AQUI / template).read_text(encoding="utf-8")
    payload = json.dumps(json.loads((AQUI / dados).read_text(encoding="utf-8")), ensure_ascii=False, separators=(",", ":"))
    payload = payload.replace("</", "<\\/")
    html = html.replace("/*__CHARTJS__*/", CHART).replace("__FONTE__", FONTE).replace("/*__DADOS__*/", payload)
    (AQUI / saida).write_text(html, encoding="utf-8")
    print(f"{saida}: {(AQUI / saida).stat().st_size / 1024:.0f} KB")


if __name__ == "__main__":
    montar("template_mart.html", "dados_mart.json", "dashboard_datamart.html")
    if (AQUI / "template_mesh.html").exists():
        montar("template_mesh.html", "dados_mesh.json", "dashboard_datamesh.html")
