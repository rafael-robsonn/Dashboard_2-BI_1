from pathlib import Path
from playwright.sync_api import sync_playwright

PLANOS = {
    "dashboard_datamart.html": [("mart_1", "top", 2), ("mart_2", 3, 4), ("mart_3", 5, 6), ("mart_4", 7, 7)],
    "dashboard_datamesh.html": [("mesh_1", "top", 2), ("mesh_2", 3, 4), ("mesh_3", 5, 5), ("mesh_4", 6, 7)],
}
SAIDA = Path(__file__).resolve().parents[1] / "relatorio" / "img"

with sync_playwright() as p:
    b = p.chromium.launch()
    for arq, cortes in PLANOS.items():
        pg = b.new_page(viewport={"width": 1440, "height": 900}, device_scale_factor=2)
        pg.goto((Path(__file__).parent / arq).resolve().as_uri())
        pg.wait_for_timeout(1200)
        caixas = pg.evaluate("[...document.querySelectorAll('.grade > section')].map(e => {const r = e.getBoundingClientRect(); return [r.top + scrollY, r.bottom + scrollY]})")
        largura = pg.evaluate("document.querySelector('.pagina').getBoundingClientRect().width")
        x0 = pg.evaluate("document.querySelector('.pagina').getBoundingClientRect().left")
        for nome, ini, fim in cortes:
            y0 = 0 if ini == "top" else caixas[ini - 1][0] - 4
            y1 = max(c[1] for c in caixas[(0 if ini == "top" else ini - 1):fim]) + 4
            pg.screenshot(path=str(SAIDA / f"{nome}.png"), full_page=True, clip={"x": x0 + 16, "y": y0, "width": largura - 32, "height": y1 - y0})
        pg.close()
    b.close()
print(sorted(x.name for x in SAIDA.iterdir()))
